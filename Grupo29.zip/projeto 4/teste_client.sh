FILE=$1
cat $FILE | \
make client
